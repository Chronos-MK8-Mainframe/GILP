
import sys
print("Python is working", flush=True)
import torch
print("Torch imported", flush=True)
from gilp_core.data.knowledge_base import KnowledgeBase
print("KB imported", flush=True)
